load('config.js');

function execute(key, page) {
    if (!page) page = '1';
    let url = `${BASE_URL}/truyen?q=${encodeURIComponent(key)}&page=${page}`;
    const proxyUrl = getProxyUrl(url);
    
    let response = fetch(proxyUrl, {
        headers: {
            "Referer": BASE_URL,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Origin": BASE_URL
        },
        bypass: true
    });
    
    if (response.ok) {
        let doc = response.html();
        let comicList = [];
        
        doc.select(".panel-manga .item").forEach(e => {
            comicList.push({
                name: e.select(".title").text(),
                link: e.select("a").first().attr("href"),
                cover: e.select(".image img").attr("src"),
                description: e.select(".chapter").text(),
                host: BASE_URL
            });
        });

        let next = doc.select(".pagination .page-item.active + .page-item").text();
        return Response.success(comicList, next);
    }
    return null;
}