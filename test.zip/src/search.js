load('config.js');

function execute(key, page) {
    if (!page) page = '1';
    let url = `${BASE_URL}/truyen?q=${encodeURIComponent(key)}&page=${page}`;
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        let comicList = [];
        
        doc.select(".panel-manga .item").forEach(e => {
            comicList.push({
                name: e.select(".title").text(),
                link: e.select("a").first().attr("href"),
                cover: e.select(".image img").attr("src"),
                description: e.select(".chapter").text(),
                host: BASE_URL
            });
        });

        let next = doc.select(".pagination .page-item.active + .page-item").text();
        return Response.success(comicList, next);
    }
    return null;
}