let BASE_URL = 'https://goctruyentranhvui17.com';
const PROXY_SERVER = 'https://cors-anywhere.herokuapp.com/'; // Proxy server public

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
    console.log(error);
}

function getProxyUrl(url) {
    // Chỉ dùng proxy khi thực sự cần thiết
    if (url.includes(BASE_URL) && !url.startsWith(PROXY_SERVER)) {
        return PROXY_SERVER + url;
    }
    return url;
}