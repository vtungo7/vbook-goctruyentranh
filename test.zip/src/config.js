let BASE_URL = 'https://goctruyentranhvui17.com';
try {
    if (CONFIG_URL) {
        // Đảm bảo URL có https://
        BASE_URL = CONFIG_URL.startsWith('http') ? CONFIG_URL : 'https://' + CONFIG_URL;
    }
} catch (error) {
    console.log(error);
}