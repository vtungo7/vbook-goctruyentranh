load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        
        let cover = doc.select(".summary_image img").attr("src");
        if (cover && cover.startsWith("//")) {
            cover = "https:" + cover;
        }

        let genres = [];
        doc.select(".genres-content a").forEach(tag => {
            genres.push(tag.text());
        });

        return Response.success({
            name: doc.select(".story-title h1").text(),
            cover: cover,
            author: doc.select(".author-content").text(),
            description: doc.select(".summary__content").text(),
            ongoing: doc.select(".post-status .summary-content").text().includes("Đang"),
            genres: genres,
            host: BASE_URL
        });
    }
    return null;
}