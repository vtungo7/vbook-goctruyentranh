load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    const proxyUrl = getProxyUrl(url);
    
    let response = fetch(proxyUrl, {
        headers: {
            "Referer": BASE_URL,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Origin": BASE_URL
        },
        bypass: true
    });
    
    if (response.ok) {
        let doc = response.html();
        
        let cover = doc.select(".summary_image img").attr("src");
        if (cover && cover.startsWith("//")) {
            cover = "https:" + cover;
        }

        let genres = [];
        doc.select(".genres-content a").forEach(tag => {
            genres.push(tag.text());
        });

        return Response.success({
            name: doc.select(".story-title h1").text(),
            cover: cover,
            author: doc.select(".author-content").text(),
            description: doc.select(".summary__content").text(),
            ongoing: doc.select(".post-status .summary-content").text().includes("Đang"),
            genres: genres,
            host: BASE_URL
        });
    }
    return null;
}