load('config.js');

function execute() {
    const doc = fetch(BASE_URL + "/the-loai").html();
    const genres = [];

    doc.select(".genres a").forEach(e => {
        genres.push({
            title: e.text(),
            input: e.attr("href").replace(BASE_URL, ""),
            script: "source.js"
        });
    });

    return Response.success(genres);
}