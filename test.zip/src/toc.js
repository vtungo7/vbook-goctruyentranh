load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    const proxyUrl = getProxyUrl(url);
    
    let response = fetch(proxyUrl, {
        headers: {
            "Referer": BASE_URL,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Origin": BASE_URL
        },
        bypass: true
    });
    
    if (response.ok) {
        let doc = response.html();
        let chapters = [];
        
        doc.select(".wp-manga-chapter").forEach(e => {
            chapters.push({
                name: e.select("a").text(),
                url: e.select("a").attr("href"),
                host: BASE_URL
            });
        });

        return Response.success(chapters);
    }
    return null;
}