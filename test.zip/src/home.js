load('config.js');
function execute() {
    return Response.success([
        {title: "Truyện mới cập nhật", input: BASE_URL + "/danh-sach-truyen", script: "source.js"},
        {title: "Truyện hoàn thành", input: BASE_URL + "/danh-sach-truyen?status=completed", script: "source.js"},
        {title: "Truyện nổi bật", input: BASE_URL + "/danh-sach-truyen?sort=views", script: "source.js"},
        {title: "Truyện yêu thích", input: BASE_URL + "/danh-sach-truyen?sort=likes", script: "source.js"}
    ]);
}