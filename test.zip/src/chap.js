load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        let imgs = [];
        
        doc.select("#lst_content img").forEach(e => {
            let imgUrl = e.attr("data-original") || e.attr("src");
            if (imgUrl && imgUrl.startsWith("//")) {
                imgUrl = "https:" + imgUrl;
            }
            if (imgUrl) {
                imgs.push(imgUrl);
            }
        });

        return Response.success(imgs);
    }
    return null;
}