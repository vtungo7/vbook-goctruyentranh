load('config.js');

function execute(url) {
    // Chuẩn hóa URL
    if (!url.startsWith('http')) {
        url = BASE_URL + (url.startsWith('/') ? url : '/' + url);
    }
    
    const proxyUrl = getProxyUrl(url);
    
    let response = fetch(proxyUrl, {
        headers: {
            "Referer": BASE_URL,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": BASE_URL
        },
        bypass: true
    });
    
    if (response.ok) {
        let doc = response.html();
        let imgs = [];
        
        doc.select("#lst_content img").forEach(e => {
            let imgUrl = e.attr("data-original") || e.attr("src");
            if (imgUrl) {
                if (imgUrl.startsWith("//")) {
                    imgUrl = "https:" + imgUrl;
                } else if (!imgUrl.startsWith("http")) {
                    imgUrl = BASE_URL + (imgUrl.startsWith('/') ? imgUrl : '/' + imgUrl);
                }
                imgs.push(imgUrl);
            }
        });

        return Response.success(imgs);
    }
    return null;
}