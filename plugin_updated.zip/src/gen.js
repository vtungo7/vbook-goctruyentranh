function execute(url, page) {
    if (!page) page = 1;
    url = url + (url.includes("?") ? "&" : "?") + "page=" + page;
    let doc = Http.get(url).html();

    let list = [];
    let elements = doc.select(".page-item-detail");

    for (let el of elements) {
        let name = el.select("h3.h5 a").text();
        let link = el.select("h3.h5 a").attr("href");
        let cover = el.select("img").attr("data-src") || el.select("img").attr("src");
        let description = el.select(".chapter.font-meta").first().text();

        list.push({
            name: name,
            link: link,
            cover: cover,
            description: description
        });
    }

    let hasNext = doc.select(".page-pagination li.active + li").text() !== "";
    let next = hasNext ? (page + 1) : null;

    return Response.success(list, next);
}
