let BASE_URL = "https://goctruyentranhvui17.com/trang-chu";


try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}