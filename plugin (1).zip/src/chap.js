function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        
        // Xử lý truyện tranh (chính)
        let imgs = [];
        doc.select("#lst_content img").forEach(e => {
            imgs.push({
                src: e.attr("data-original") || e.attr("src"),
                alt: e.attr("alt") || "",
                referrerPolicy: "no-referrer"
            });
        });

        // Thông tin chương
        const chapterInfo = {
            title: doc.select(".chapter-title").text() || "",
            prevChapter: doc.select(".prev-chap").attr("href") || "",
            nextChapter: doc.select(".next-chap").attr("href") || ""
        };

        return Response.success({
            images: imgs,
            chapterInfo: chapterInfo,
            host: "https://goctruyentranhvui17.com"
        });
    }
    return null;
}