function execute(url) {
    const doc = fetch(url).html();

    const name = doc.select(".story-title h1").text();
    const cover = doc.select(".summary_image img").attr("src");
    const description = doc.select(".summary__content").text();

    const author = doc.select(".author-content").text();
    const ongoing = doc.select(".post-status .summary-content").text().includes("Đang") ? true : false;

    const genres = [];
    doc.select(".genres-content a").forEach(tag => {
        genres.push(tag.text());
    });

    return Response.success({
        name,
        cover,
        author,
        description,
        ongoing,
        genres,
        host: "https://goctruyentranhvui17.com"
    });
}
