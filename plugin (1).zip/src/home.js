function execute() {
    return Response.success([
        {title: "Danh sách thể loại", script: "genre.js"},
        {title: "Truyện mới", input: "/danh-sach-truyen", script: "source.js"},
        {title: "Truyện hoàn thành", input: "/danh-sach-truyen?status=completed", script: "source.js"},
        {title: "Bảng xếp hạng", script: "bxh.js"}
    ]);
}
