function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: "/danh-sach-truyen", script: "source.js"},
        {title: "Hoàn thành", input: "/danh-sach-truyen?status=completed", script: "source.js"}
    ]);
}
