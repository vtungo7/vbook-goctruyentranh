function execute() {
    return Response.success([
        {title: "Truyện nổi bật", input: "/danh-sach-truyen?sort=views", script: "source.js"},
        {title: "Yêu thích", input: "/danh-sach-truyen?sort=likes", script: "source.js"}
    ]);
}
