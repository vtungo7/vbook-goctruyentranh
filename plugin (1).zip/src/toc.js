function execute(url) {
    const doc = fetch(url).html();
    const chapters = [];

    doc.select(".wp-manga-chapter").forEach(e => {
        chapters.push({
            name: e.select("a").text(),
            url: e.select("a").attr("href"),
            host: "https://goctruyentranhvui17.com"
        });
    });

    return Response.success(chapters);
}
