function execute(url, page) {
    if (!page) page = '1';
    const fullUrl = `https://goctruyentranhvui17.com${url}&page=${page}`;
    const doc = fetch(fullUrl).html();

    const list = [];
    doc.select(".panel-manga .item").forEach(e => {
        list.push({
            name: e.select(".title").text(),
            link: e.select("a").first().attr("href"),
            cover: e.select(".image img").attr("src"),
            description: e.select(".chapter").text(),
            host: "https://goctruyentranhvui17.com"
        });
    });

    const next = doc.select(".pagination .page-item.active + .page-item").text();
    return Response.success(list, next);
}
