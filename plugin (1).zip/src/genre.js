function execute() {
    const doc = fetch("https://goctruyentranhvui17.com/the-loai").html();
    const genres = [];

    doc.select(".genres a").forEach(e => {
        genres.push({
            title: e.text(),
            input: e.attr("href").replace("https://goctruyentranhvui17.com", ""),
            script: "source.js"
        });
    });

    return Response.success(genres);
}
